<?php
session_start();
if ($_POST['username'] === 'abosham' && $_POST['password'] === 'Abosham') {
    $_SESSION['admin'] = true;
    header("Location: admin/dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>Login</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body class="bg-light">
<div class="container mt-5">
    <h2 class="text-center mb-4">لوحة دخول Abosham</h2>
    <form method="POST" class="card p-4 shadow">
        <input name="username" class="form-control mb-3" placeholder="اسم المستخدم" required>
        <input name="password" type="password" class="form-control mb-3" placeholder="كلمة المرور" required>
        <button class="btn btn-primary w-100">تسجيل الدخول</button>
    </form>
</div>
</body>
</html>