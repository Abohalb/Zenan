<?php
require 'db.php';
$user_slug = $_GET['user'] ?? '';
if (!$user_slug) die("Invalid user.");
$stmt = $pdo->prepare("SELECT * FROM users WHERE slug = ?");
$stmt->execute([$user_slug]);
$user = $stmt->fetch();
if (!$user || strtotime($user['expires_at']) < time()) {
    die("Subscription expired or user not found.");
}
$iptv_url = "http://familyplus.me:8080/get.php?username=211540129524&password=68696b6246951&type=m3u_plus&output=ts";
header("Location: $iptv_url");
exit;
?>