<?php
session_start();
if (!isset($_SESSION['admin'])) die("Unauthorized.");
require '../db.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $slug = $_POST['slug'];
    $days = intval($_POST['duration']);
    $expires = date("Y-m-d H:i:s", strtotime("+$days days"));
    $stmt = $pdo->prepare("INSERT INTO users (name, slug, expires_at) VALUES (?, ?, ?)");
    $stmt->execute([$name, $slug, $expires]);
    header("Location: dashboard.php");
    exit;
}
?>
<!DOCTYPE html>
<html>
<head><title>إضافة مستخدم</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-4">
    <h2>➕ إضافة مشترك جديد</h2>
    <form method="POST" class="card p-4">
        <input name="name" class="form-control mb-3" placeholder="الاسم" required>
        <input name="slug" class="form-control mb-3" placeholder="المعرف (slug)" required>
        <input name="duration" type="number" class="form-control mb-3" placeholder="مدة الاشتراك بالأيام" required>
        <button class="btn btn-primary">حفظ</button>
    </form>
</div>
</body>
</html>