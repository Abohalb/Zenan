<?php
session_start();
if (!isset($_SESSION['admin'])) die("Unauthorized.");
require '../db.php';
$users = $pdo->query("SELECT * FROM users ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html>
<head><title>لوحة التحكم</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet"></head>
<body>
<div class="container mt-4">
    <h2 class="mb-4">لوحة تحكم Abosham</h2>
    <a href="add.php" class="btn btn-success mb-3">➕ إضافة مستخدم</a>
    <table class="table table-bordered">
        <thead><tr><th>الاسم</th><th>الرابط</th><th>انتهاء الاشتراك</th><th>خيارات</th></tr></thead>
        <tbody>
            <?php foreach ($users as $u): ?>
            <tr>
                <td><?= $u['name'] ?></td>
                <td><a href="../iptv.php?user=<?= $u['slug'] ?>" target="_blank">رابط المشاهدة</a></td>
                <td><?= $u['expires_at'] ?></td>
                <td>
                    <a href="edit.php?id=<?= $u['id'] ?>" class="btn btn-warning btn-sm">تعديل</a>
                    <a href="delete.php?id=<?= $u['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('حذف المستخدم؟')">حذف</a>
                </td>
            </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>
</body>
</html>