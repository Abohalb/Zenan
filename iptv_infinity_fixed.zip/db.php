<?php
$pdo = new PDO("mysql:host=sql206.infinityfree.com;dbname=0_38941909", "0_38941909", "VrMIAOXf2pMQuM");
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
?>